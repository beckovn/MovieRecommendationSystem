import java.util.*;

public class FourthRatings {
    public FourthRatings() {
    }
    
    // Average movie rating for this movieID (id),
    // if there are at least minimalRaters number of ratings.
    // If there aren't at least minimalRaters number of ratings,
    // return 0
    private double getAverageByID(String id, int minimalRaters) {
        int ratingsCount = 0;
        double ratingsSum = 0;
        ArrayList<Rater> allRaters = RaterDatabase.getRaters();
        
        // calculate the number of raters for id (movieID)
        // and the sum of their ratings
        for(Rater r : allRaters) {
            
            // if this movie has a rating
            if(r.getRating(id)>0) {
                ratingsCount++;
                ratingsSum += r.getRating(id);
            }
        }
        
        // return the appropriate number
        if(ratingsCount<minimalRaters) return 0;
        else return ratingsSum/ratingsCount;
    }
    
    // returns an ArrayList<Rating> with the average ratings
    // for all movies with a number of minimalRaters
    public ArrayList<Rating> getAverageRatings(int minimalRaters) {
        ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());
        ArrayList<Rating> ra = new ArrayList<Rating>();
        
        // loop through all movieIDs, get their average ratings
        // and add them as Ratings to ra
        for(String movieID : movies) {
            if(getAverageByID(movieID, minimalRaters)>0) {
                Rating r = new Rating(movieID, getAverageByID(movieID,
                                                              minimalRaters));
                ra.add(r);
            }
        }
        
        return ra;
    }
    
    // returns an ArrayList with Ratings, satisfying a filterCriteria,
    // with minimalRaters
    public ArrayList<Rating> getAverageRatingsByFilter(int minimalRaters,
                                                       Filter filterCriteria) {
        ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());
        ArrayList<Rating> ra = new ArrayList<Rating>();
        
        // loop through all movieIDs
        for(String movieID : movies) {
            if (filterCriteria.satisfies(movieID) &&
                getAverageByID(movieID, minimalRaters)>0) {
                ra.add(new Rating(movieID, getAverageByID(movieID,
                                                          minimalRaters)));
            }
        }
        
        return ra;
    }
    
    // translate a rating from scale 0:10 to scale -5:5 and
    // return the raterID and the dot product of the ratings
    // of movies we both watched and rated
    private Rating dotProduct(Rater me,
                              Rater er) {
        double dotProd = 0;
        
        // Loop through the all the movies in MovieDatabase
        for(String movieID : MovieDatabase.filterBy(new TrueFilter())) {
            
            // if the same movieID is rated by er and me
            if(me.hasRating(movieID) && er.hasRating(movieID)) {
                
                // add the subtracted with half (5) points ratings'
                // product to the dotProd variable 
                dotProd += (er.getRating(movieID) - 5)
                            *(me.getRating(movieID) - 5);
            }
        }
        
        // make a Rating object from the raterID and dotProduct
        Rating ret = new Rating(er.getID(), dotProd);
        
        return ret;
    }
    
    // computes a similarity rating for each rater in the RaterDatabase
    // (except the rater with the ID given by the parameter)
    private ArrayList<Rating> getSimilarities(String id) {
        ArrayList<Rating> list = new ArrayList<Rating>();
        
        Rater me = RaterDatabase.getRater(id);
        
        // loop through all the raters in the database
        for(Rater r : RaterDatabase.getRaters()) {
            
            // if Rater r is different than me,
            // compute their similarity with me
            if(!r.getID().equals(me.getID())) {
                // transform Rater r to EfficientRater
                                
                // Rater
                String raterID = dotProduct(me, r).getItem();
                
                // similarity product
                double prod = dotProduct(me, r).getValue();
                
                // add only positive similarity ratings
                if(prod>0) {
                    list.add(new Rating(raterID, prod));
                }
            }
        }
        
        // sort descending
        Collections.sort(list, Collections.reverseOrder());
        
        return list;
    }
    
    // returns an ArrayList of Ratings, of movies and their
    // weighted average ratings, using only the top numSimilarRaters
    // with positive ratings and including only movies that have at least
    // minimalRaters ratings from those most similar raters
    public ArrayList<Rating> getSimilarRatings(String id, // raterID
                                               int numSimilarRaters,
                                               int minimalRaters) {
        int ratersCounter = 0;
        double sumWeightedRatings = 0;
                                                   
        // An ArrayList of movies and their weighted average ratings
        ArrayList<Rating> rali = new ArrayList<Rating>();
        
        // ArrayList with raterID and weighted similarity value
        ArrayList<Rating> allsim = getSimilarities(id);
        
        // check which movies have at least minimalRaters
        // ratings by numSimilarRaters raters
        for(String movieID : MovieDatabase.filterBy(new TrueFilter())) {
            ratersCounter = 0;
            sumWeightedRatings = 0;
            
            // loop through all top similar raterIDs
            for(int i=0; i<numSimilarRaters; i++) {
                
                // If Rater allsim.get(i) has Rating for movieID
                if(RaterDatabase.getRater(allsim.get(i).getItem()).hasRating(movieID)) {
                    ratersCounter++;
                    sumWeightedRatings = sumWeightedRatings +
                        allsim.get(i).getValue()*
                        RaterDatabase.getRater(allsim.get(i).getItem()).getRating(movieID);
                }
            }
            
            // if condition for minimalRaters is met
            if(ratersCounter>=minimalRaters) {
                double weightedAverage = sumWeightedRatings/ratersCounter;
                
                // add movie and average weighted rating
                rali.add(new Rating(movieID, weightedAverage));
            }
        }
        
        // sort descending
        Collections.sort(rali, Collections.reverseOrder());
        
        return rali;
    }
    
    // similar to the getSimilarRatings method, with additional Filter parameter
    // filterCriteria; uses that filter to access and rate only those movies that
    // match the filter criteria
    public ArrayList<Rating> getSimilarRatingsByFilter(String id, // raterID
                                                       int numSimilarRaters,
                                                       int minimalRaters,
                                                       Filter filterCriteria) {
        // An ArrayList of movies and their weighted average ratings
        ArrayList<Rating> rali = getSimilarRatings(id,
                                                   numSimilarRaters,
                                                   minimalRaters);
        ArrayList<Rating> ret = new ArrayList<Rating>();
        
        // loop through all movieIDs in rali
        for(Rating r : rali) {
            // if filterCriteria is satisfied, add it to ret
            if (filterCriteria.satisfies(r.getItem())) {
                ret.add(new Rating(r.getItem(), r.getValue()));
            }
        }
        
        return ret;
    }
}
