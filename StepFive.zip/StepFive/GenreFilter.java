
public class GenreFilter implements Filter {
    private String ge;
    
    public GenreFilter(String genre) {
        ge = genre;
    }
    
    public boolean satisfies(String id) {
        if(MovieDatabase.getGenres(id).contains(ge)) {
            return true;
        } else return false;
    }
}
