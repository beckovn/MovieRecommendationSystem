import java.util.*;

public class MovieRunnerSimilarRatings {
    public void printAverageRatings() {
        int minimalRaters = 35;
        FourthRatings fra = new FourthRatings();
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList with average ratings
        ArrayList<Rating> ra = fra.getAverageRatings(minimalRaters);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings returned (with "+
            "minimal raters of "+minimalRaters+") is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
                
        // print all the average ratings
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "+MovieDatabase.getTitle(r.getItem()));
        }
    }
    
    public void printAverageRatingsByYearAfterAndGenre() {
        AllFilters af = new AllFilters();
        int minimalRaters = 35;
        FourthRatings fra = new FourthRatings();
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // create an YearAfterFilter
        YearAfterFilter ya = new YearAfterFilter(1990);
        
        // add the YearAfterFilter to the list of filters
        af.addFilter(ya);
        
        // create a GenreFilter
        GenreFilter gf = new GenreFilter("Drama");
        
        // add the GenreFilter to the list of filters
        af.addFilter(gf);
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by YearAfterAndGenre
        ArrayList<Rating> ra = fra.getAverageRatingsByFilter(minimalRaters,
                                                             af);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by YearAfterAndGenre returned (with "+
            "minimal raters of "+minimalRaters+") is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by YearAfterAndGenre
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "
                    +MovieDatabase.getYear(r.getItem())+" "
                    +MovieDatabase.getTitle(r.getItem()));
            System.out.println("\t"+MovieDatabase.getGenres(r.getItem()));
        }
    }
    
    public void printSimilarRatings() {
        FourthRatings fra = new FourthRatings();
        String raterID = "71";
        int numMinRaters = 5, topSimRaters = 20;
        
        // initialize RaterDatabase
        RaterDatabase.initialize("ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings
        ArrayList<Rating> ra = fra.getSimilarRatings(raterID,
                                                     topSimRaters,
                                                     numMinRaters);
        
        // print the recomended movies and their Similarity rating
        for(Rating r : ra) {
            System.out.println(MovieDatabase.getTitle(r.getItem())+" - "+
                r.getValue());
        }
    }
    
    public void printSimilarRatingsByDirector() {
        FourthRatings fra = new FourthRatings();
        String raterID = "120";
        int numMinRaters = 2, topSimRaters = 10;
        
        // create a GenreFilter
        DirectorsFilter df = new DirectorsFilter("Clint Eastwood,J.J. Abrams,Alfred Hitchcock,Sydney Pollack,David Cronenberg,Oliver Stone,Mike Leigh");
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings, by Director(s)
        ArrayList<Rating> ra = fra.getSimilarRatingsByFilter(raterID,
                                                             topSimRaters,
                                                             numMinRaters,
                                                             df);
        
        // print the recomended movies and their Similarity rating
        for(Rating r : ra) {
            System.out.println(MovieDatabase.getTitle(r.getItem())+" - "+
                r.getValue());
        }
    }
    
    public void printSimilarRatingsByGenre() {
        FourthRatings fra = new FourthRatings();
        String raterID = "964";
        int numMinRaters = 5, topSimRaters = 20;
        
        // create a GenreFilter
        GenreFilter gf = new GenreFilter("Mystery");
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings, by Genre
        ArrayList<Rating> ra = fra.getSimilarRatingsByFilter(raterID,
                                                             topSimRaters,
                                                             numMinRaters,
                                                             gf);
        
        // print the recomended movies and their Similarity rating
        for(Rating r : ra) {
            System.out.println(MovieDatabase.getTitle(r.getItem())+" - "+
                r.getValue());
        }
    }
    
    public void printSimilarRatingsByGenreAndMinutes() {
        FourthRatings fra = new FourthRatings();
        String raterID = "168";
        int numMinRaters = 3, topSimRaters = 10;
        AllFilters af = new AllFilters();
        
        // create a GenreFilter
        GenreFilter gf = new GenreFilter("Drama");
        
        // create a MinutesFilter
        MinutesFilter mf = new MinutesFilter(80, 160);
        
        // adding both Genre and Minutes filters to AllFilters
        af.addFilter(gf);
        af.addFilter(mf);
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings, by Genre
        ArrayList<Rating> ra = fra.getSimilarRatingsByFilter(raterID,
                                                             topSimRaters,
                                                             numMinRaters,
                                                             af);
        
        // print the recomended movies and their Similarity rating
        for(Rating r : ra) {
            System.out.println(MovieDatabase.getTitle(r.getItem())+" - "+
                r.getValue());
        }
    }
    
    public void printSimilarRatingsByYearAfterAndMinutes() {
        FourthRatings fra = new FourthRatings();
        String raterID = "314";
        int numMinRaters = 5, topSimRaters = 10;
        AllFilters af = new AllFilters();
        
        // create a GenreFilter
        YearAfterFilter yaf = new YearAfterFilter(1975);
        
        // create a MinutesFilter
        MinutesFilter mf = new MinutesFilter(70, 200);
        
        // adding both Genre and Minutes filters to AllFilters
        af.addFilter(yaf);
        af.addFilter(mf);
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        System.out.println("Number of raters in RaterDatabase is "+RaterDatabase.size());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings, by Genre
        ArrayList<Rating> ra = fra.getSimilarRatingsByFilter(raterID,
                                                             topSimRaters,
                                                             numMinRaters,
                                                             af);
        
        // print the recomended movies and their Similarity rating
        for(Rating r : ra) {
            System.out.println(MovieDatabase.getTitle(r.getItem())+" - "+
                r.getValue());
        }
    }
}
