import java.util.*;

public class MovieRunnerWithFilters {
    public void printAverageRatings() {
        int minimalRaters = 35;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        System.out.println("Number of raters is "+tr.getRaterSize());
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        // get an ArrayList with average ratings
        ArrayList<Rating> ra = tr.getAverageRatings(minimalRaters);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
                
        // print all the average ratings
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "+MovieDatabase.getTitle(r.getItem()));
        }
    }
    
    public void printAverageRatingsByYear() {
        YearAfterFilter ya = new YearAfterFilter(2000);
        int minimalRaters = 20;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by YearAfterFilter
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            ya);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by YearAfterFilter returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by YearAfterFilter
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "
                    +MovieDatabase.getYear(r.getItem())+" "
                    +MovieDatabase.getTitle(r.getItem()));
        }
    }
    
    public void printAverageRatingsByGenre() {
        GenreFilter gf = new GenreFilter("Comedy");
        int minimalRaters = 20;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by GenreFilter
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            gf);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by GenreFilter returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by GenreFilter
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "
                    +MovieDatabase.getTitle(r.getItem()));
            System.out.println("\t"+MovieDatabase.getGenres(r.getItem()));
        }
    }
    
    public void printAverageRatingsByMinutes() {
        MinutesFilter mf = new MinutesFilter(105, 135);
        int minimalRaters = 5;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by MinutesFilter
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            mf);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by MinutesFilter returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by MinutesFilter
        for(Rating r : ra) {
            System.out.println(r.getValue()+", Time: "
                    +MovieDatabase.getMinutes(r.getItem())+", "
                    +MovieDatabase.getTitle(r.getItem()));
        }
    }
    
    
    public void printAverageRatingsByDirectors() {
        DirectorsFilter df =
            new DirectorsFilter("Clint Eastwood,Joel Coen,Martin Scorsese,Roman Polanski,Nora Ephron,Ridley Scott,Sydney Pollack");
        int minimalRaters = 4;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by DirectorsFilter
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            df);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by DirectorsFilter returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by DirectorsFilter
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "
                    +MovieDatabase.getTitle(r.getItem()));
            System.out.println("\t"+MovieDatabase.getDirector(r.getItem()));
        }
    }
    
    public void printAverageRatingsByYearAfterAndGenre() {
        AllFilters af = new AllFilters();
        int minimalRaters = 35;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // create an YearAfterFilter
        YearAfterFilter ya = new YearAfterFilter(1990);
        
        // add the YearAfterFilter to the list of filters
        af.addFilter(ya);
        
        // create a GenreFilter
        GenreFilter gf = new GenreFilter("Drama");
        
        // add the GenreFilter to the list of filters
        af.addFilter(gf);
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by YearAfterAndGenre
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            af);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by YearAfterAndGenre returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by YearAfterAndGenre
        for(Rating r : ra) {
            System.out.println(r.getValue()+" "
                    +MovieDatabase.getYear(r.getItem())+" "
                    +MovieDatabase.getTitle(r.getItem()));
            System.out.println("\t"+MovieDatabase.getGenres(r.getItem()));
        }
    }
    
    public void printAverageRatingsByDirectorsAndMinutes() {
        AllFilters af = new AllFilters();
        int minimalRaters = 3;
        ThirdRatings tr = new ThirdRatings("data/ratings.csv");
        
        // create a DirectorsFilter
        DirectorsFilter df =
            new DirectorsFilter("Clint Eastwood,Joel Coen,Tim Burton,Ron Howard,Nora Ephron,Sydney Pollack");
        
        // add the DirectorsFilter to the list of filters
        af.addFilter(df);
        
        // create a MinutesFilter
        MinutesFilter mf = new MinutesFilter(90, 180);
        
        // add the MinutesFilter to the list of filters
        af.addFilter(mf);
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
                
        // get an ArrayList with average ratings by DirectorsAndMinutes filters
        ArrayList<Rating> ra = tr.getAverageRatingsByFilter(minimalRaters,
                                                            af);
        
        // printing out how many movies with ratings are returned
        System.out.println("Number movies with ratings by DirectorsAndMinutes returned is "+ra.size());
        
        // sorting the ArrayList
        Collections.sort(ra);
        
        // print all the average ratings by DirectorsAndMinutes
        for(Rating r : ra) {
            System.out.println(r.getValue()+", Time: "
                    +MovieDatabase.getMinutes(r.getItem())+", "
                    +MovieDatabase.getTitle(r.getItem()));
            System.out.println("\t"+MovieDatabase.getDirector(r.getItem()));
        }
    }
}
