import java.util.*;

public class SecondRatings {
    private ArrayList<Movie> myMovies;
    private ArrayList<PlainRater> myRaters;
    
    public SecondRatings() {
        this("data/ratedmoviesfull.csv", "data/ratings.csv");
    }
    
    public SecondRatings(String moviefile, String ratingsfile) {
        FirstRatings fr = new FirstRatings();
        myMovies = fr.loadMovies(moviefile);
        myRaters = fr.loadRaters(ratingsfile);
    }
    
    // how much movies were loaded
    public int getMovieSize() {
        return myMovies.size();
    }
    
    // how much rater records were loaded
    public int getRaterSize() {
        return myRaters.size();
    }
    
    // Average movie rating for this movieID (id),
    // if there are at least minimalRaters number of ratings.
    // If there aren't at least minimalRaters number of ratings,
    // return 0
    private double getAverageByID(String id, int minimalRaters) {
        int ratingsCount = 0;
        double ratingsSum = 0;
        
        // calculate the number of raters for id (movieID)
        // and the sum of their ratings
        for(PlainRater r : myRaters) {
            for(Rating rat : r.getRatings()) {
                if(rat.getItem().equals(id)) {
                    ratingsCount++;
                    ratingsSum += rat.getValue();
                }
            }
        }
        
        // return the appropriate number
        if(ratingsCount<minimalRaters) return 0;
        else return ratingsSum/ratingsCount;
    }
    
    // returns an ArrayList<Rating> with the average ratings
    // for all movies with a number of minimalRaters
    public ArrayList<Rating> getAverageRatings(int minimalRaters) {
        ArrayList<Rating> ra = new ArrayList<Rating>();
        
        // loop through all movies, get their average ratings
        // and add them as Ratings to ra
        for(Movie m : myMovies) {
            if(getAverageByID(m.getID(), minimalRaters)>0) {
                Rating r = new Rating(m.getID(), getAverageByID(m.getID(),
                                                                minimalRaters));
                ra.add(r);
            }
        }
        
        return ra;
    }
    
    // returns the title of the movie with movieID = id
    public String getTitle(String id) {
        for(Movie m : myMovies) {
            if(m.getID().equals(id)) {
                return m.getTitle();
            }
        }
        return "No Title found";
    }
    
    // returns the movieID of a movie with given title
    public String getID(String title) {
        for(Movie m : myMovies) {
            if(m.getTitle().equals(title)) {
                return m.getID();
            }
        }
        return "NO SUCH TITLE.";
    }
}
