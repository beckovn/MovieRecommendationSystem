
public class DirectorsFilter implements Filter {
    private String directors;
    
    public DirectorsFilter(String dir) {
        directors = dir;
    }
    
    public boolean satisfies(String id) {
        String[] dir = directors.split(",");
        
        for(String d : dir) {
            if(MovieDatabase.getDirector(id).contains(d)) {
                return true;
            }
        }
        
        return false;
    }
}
