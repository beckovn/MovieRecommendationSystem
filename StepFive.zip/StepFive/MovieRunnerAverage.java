import java.util.*;

public class MovieRunnerAverage {
    public void printAverageRatings() {
        int minimalRaters = 12;
        double minRating = -1;
        String movieTitle = "";
        SecondRatings sr = new SecondRatings("data/ratedmoviesfull.csv",
                                             "data/ratings.csv");
        System.out.println("Number of movies is "+sr.getMovieSize());
        System.out.println("Number of raters is "+sr.getRaterSize());
        
        // get an ArrayList with average ratings
        ArrayList<Rating> ra = sr.getAverageRatings(minimalRaters);
        
        // print all the average ratings
        // and get the lowest rating
        for(Rating r : ra) {
            //System.out.println(r.getValue()+" "+sr.getTitle(r.getItem()));
            
            // get the movie with the lowest rating
            if(minRating == -1) {
                minRating = r.getValue();
                movieTitle = sr.getTitle(r.getItem());
            } else if(r.getValue()<minRating) {
                minRating = r.getValue();
                movieTitle = sr.getTitle(r.getItem());
            }
        }
        System.out.println("Movie with lowest rating - "+minRating+", is "+movieTitle);
        System.out.println(ra.size()+" movies have "+minimalRaters+" or more ratings.");
    }
    
    public void getAverageRatingOneMovie() {
        int minimalRaters = 3;
        String movieTitle = "Vacation";
        SecondRatings sr = new SecondRatings("data/ratedmoviesfull.csv",
                                             "data/ratings.csv");
        // get an ArrayList with average ratings
        ArrayList<Rating> ra = sr.getAverageRatings(minimalRaters);
        
        // print the average rating of the movie with
        // title = movieTitle
        for(Rating r : ra) {
            if(r.getItem().equals(sr.getID(movieTitle))) {
                System.out.println("The movie "+movieTitle+" has an average rating "+r.getValue());
            }
        }
        ;
    }
}
