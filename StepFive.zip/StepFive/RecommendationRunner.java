import java.util.*;

public class RecommendationRunner implements Recommender {
    
    // returns an ArrayList with movieIDs to rate,
    // filtered by an YearAfter and Minutes filters
    public ArrayList<String> getItemsToRate () {
        // an ArrayList to load with movies (movieIDs)
        // and return
        ArrayList<String> al = new ArrayList<String>();
        
        FourthRatings fra = new FourthRatings();
        
        // minimal raters
        int minimalRaters = 20;
        
        // create a MinutesFilter
        MinutesFilter mf = new MinutesFilter(90, 150);
        
        // create an YearAfterFilter
        YearAfterFilter ya = new YearAfterFilter(1990);
        
        // AllFilters to add the other two filters
        AllFilters af = new AllFilters();
        
        // adding the filters
        af.addFilter(mf);
        af.addFilter(ya);
        
        // initialize MovieDatabase
        MovieDatabase.initialize("ratedmoviesfull.csv");
        
        // initialize RaterDatabase
        RaterDatabase.initialize("ratings.csv");
        
        // print number of raters in the database
        System.out.println("Number of raters is "+RaterDatabase.size());
        // print number of movies in the database
        System.out.println("The number of movies in MovieDatabase is "+MovieDatabase.size());
        
        
        // get an ArrayList with average ratings by AllFilters
        // (a Rating contains a pair: movieID, Value)
        ArrayList<Rating> ra = fra.getAverageRatingsByFilter(minimalRaters,
                                                             af);
        
        // sort descending
        Collections.sort(ra, Collections.reverseOrder());
        
        // add the chosen movies to al
        for(int i=0; i<20; i++) {
            al.add(ra.get(i).getItem());
        }
        
        return al;
    }
    
    // print HTML table with recommendations for the raterID
    public void printRecommendationsFor (String webRaterID) {
        FourthRatings fra = new FourthRatings();
        int numMinRaters = 5, topSimRaters = 20;
        
        // initialize MovieDatabase
        MovieDatabase.initialize("data/ratedmoviesfull.csv");
        
        // initialize RaterDatabase
        RaterDatabase.initialize("data/ratings.csv");
        
        // get an ArrayList of Ratings, of movies (movieID) and
        // their weighted average ratings
        ArrayList<Rating> ra = fra.getSimilarRatings(webRaterID,
                                                     topSimRaters,
                                                     numMinRaters);
        
        if(ra.size()>0) {
                                                     
            // print the recomended movies and their Similarity rating
            System.out.println("<table>");
            for(Rating r : ra) {
                // only show those movies that weren't rated by webRaterID
                if(!RaterDatabase.getRater(webRaterID).hasRating(r.getItem())) {
                    System.out.println("<tr><th>"+MovieDatabase.getTitle(
                        r.getItem())+"</th><th>"+
                        r.getValue()+"</th></tr>");
                }
            }
            System.out.println("</table>");
        }
    }
}
