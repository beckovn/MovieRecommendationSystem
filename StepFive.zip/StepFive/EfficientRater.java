import java.util.*;

public class EfficientRater implements Rater {
    private String myID;
    
    // the key is movieID, the value is its Rating
    private HashMap<String,Rating> myRatings;

    public EfficientRater(String id) {
        myID = id;
        myRatings = new HashMap<String,Rating>();
    }

    public void addRating(String movieID, double rating) {
        myRatings.put(movieID, new Rating(movieID,rating));
    }

    public boolean hasRating(String item) {
        if(myRatings.containsKey(item)) return true;
        else return false;
    }

    public String getID() {
        return myID;
    }
    
    public double getRating(String item) {
        if(myRatings.containsKey(item)) {
            return myRatings.get(item).getValue();
        } else return -1;
    }

    public int numRatings() {
        return myRatings.size();
    }

    public ArrayList<String> getItemsRated() {
        ArrayList<String> list = new ArrayList<String>();
        	
        for (String s : myRatings.keySet()) {
            list.add(s);
        }
        
        return list;
    }
}
