import edu.duke.*;
import java.util.*;
import org.apache.commons.csv.*;
import java.io.*;

public class FirstRatings {
    
    // loading all movies from a file into an ArrayList and
    // retruning it
    public ArrayList<Movie> loadMovies(String filename) {
        // empty ArrayList to load data in and return
        ArrayList<Movie> al = new ArrayList<Movie>();
        
        // creating a FileResource from the filename input
        FileResource fr = new FileResource("data/"+filename);
        
        // loop through the records without the header -
        // currently the header of the file is:
        // id,title,year,country,genre,director,minutes,poster
        for(CSVRecord rec : fr.getCSVParser(true)) {
            Movie m = new Movie(rec.get(0), // id
                                rec.get(1), // title
                                rec.get(2), // year
                                rec.get(4), // genres
                                rec.get(5), // director
                                rec.get(3), // country
                                rec.get(7), // poster
                                Integer.parseInt(rec.get(6)) // minutes
                                );
            
            // add the newly created movie object to the ArrayList
            al.add(m);
        }
            
        return al;
    }
    
    public void testLoadMovies() {
        String fileName = "data/ratedmoviesfull.csv";
        ArrayList<Movie> al = loadMovies(fileName);
        System.out.println("Number of movies in the file: "+al.size());
        int countComedies = 0, countLong = 0, length = 150, maxMovies = 0;
        String dirName = "";
        HashMap<String, Integer> dir = new HashMap<String, Integer>();
        
        // printing each movie using the Movie's own
        // toString method
        //for(Movie m : al) {
        //    System.out.println(m.toString());
        //}
        
        // counting: number of comedies; longer than "length" movies;
        // how many movies has each director directed
        for(Movie m : al) {
            if(m.getGenres().contains("Comedy")) {
                countComedies++;
            }
            if(m.getMinutes()>length) {
                countLong++;
            }
            
            // more than one director for the movie
            if(m.getDirector().contains(",")) {
                
                // create a String array with the directors' names
                // as elements
                String[] directors = m.getDirector().split(", ");
                for(int i = 0; i<directors.length; i++) {
                    
                    // if the name of the director is already in
                    // the HashMap, than add +1 to his number of directed
                    // movies
                    if(dir.containsKey(directors[i])) {
                        dir.put(directors[i], dir.get(directors[i])+1);
                    } else {
                        dir.put(directors[i], 1);
                    }
                }
            }
            
            // only one director of the movie
            else {
                // if the name of the director is already in
                // the HashMap, than add +1 to his number of directed
                // movies
                if(dir.containsKey(m.getDirector())) {
                    dir.put(m.getDirector(), dir.get(m.getDirector())+1);
                } else {
                    dir.put(m.getDirector(), 1);
                }
            }
            //System.out.println(m.getDirector());
        }
        System.out.println("Number of comedies: "+countComedies);
        System.out.println("Number of movies greater than "+length+" minutes: "+countLong);
        
        // check which director made the most movies
        for(String name : dir.keySet()) {
            //System.out.println("Director "+name+" has "+dir.get(name)+" movies.");
            if(dir.get(name)>maxMovies) {
                maxMovies = dir.get(name);
                dirName = name;
            }
        }
        System.out.println("The director with most movies ("+maxMovies+") is "+dirName+".");
    }
    
    // loading all raters and their ratings from a file
    // into an ArrayList and retruning it
    public ArrayList<PlainRater> loadRaters(String filename) {
        // empty ArrayList to load data in and return
        ArrayList<PlainRater> al = new ArrayList<PlainRater>();
        int addRatingFlag = 0;
        
        // creating a FileResource from the filename input
        FileResource fr = new FileResource(filename);
        
        // loop through the records without the header -
        // currently the header of the file is:
        // rater_id,movie_id,rating,time
        for(CSVRecord rec : fr.getCSVParser(true)) {
            
            // check if list already contains this rater
            for(PlainRater r : al) {
                // rec.get(0) -> rater_id
                if(r.getID().equals(rec.get(0))) {
                    // if yes, add only the new Rating
                    r.addRating(rec.get(1), // movie_id
                                Double.parseDouble(rec.get(2))  // rating
                               );
                    
                    // change onlyRating flag
                    addRatingFlag = 1;
                }
            }
            
            // if rater_id was found and Rating added,
            // go to next iteration
            if(addRatingFlag == 1) {
                addRatingFlag = 0;
                continue;
            }
            
            // if rater is new, create him and add his 1st Rating
            else {
                // creating a Rater object with rater_id
                PlainRater r = new PlainRater(rec.get(0) // rater_id
                                    );
            
                // adding the rating to the object
                r.addRating(rec.get(1), // movie_id
                            Double.parseDouble(rec.get(2))  // rating
                            );
            
                // add the newly created Rater object to the ArrayList
                al.add(r);
            }
        }
        
        return al;
    }
    
    public void testLoadRaters() {
        // ratings.csv = 1048
        String fileName = "data/ratings.csv";
        ArrayList<PlainRater> al = loadRaters(fileName);
        ArrayList<String> totalMoviesCount = new ArrayList<String>();
        String givenRater = "193", movieID = "1798709", raterWithMaxRatings = "";
        int sum = 0, maxNumberRatings = 0, countMaxNumRatings = 0,
            countMovieRatings = 0;
        
        // printing raters and their ratings
        //for(Rater r : al) {
        //    System.out.println("Rater ID: "+r.getID()+
        //            ", with number of ratings "+r.numRatings());
        //    for(Rating ra: r.getRatings()) {
        //        System.out.println(ra.toString());
        //    }
        //}
        
        System.out.println("Number of raters in the file: "+al.size());
        
        // counting the total number of ratings
        // and the maximum number per all raters
        for(PlainRater r : al) {
            sum += r.getRatings().size();
            if(r.getRatings().size()>maxNumberRatings) {
                maxNumberRatings = r.getRatings().size();
                raterWithMaxRatings = r.getID();
            }
        }
        System.out.println("Number of ratings in the file: "+sum);
        
        // check how many ratings a givenRater has
        for(PlainRater r : al) {
            if(r.getID().equals(givenRater)) {
                System.out.println("Rater with ID "+givenRater+
                            " has "+r.getRatings().size()+" Rating(s).");
            }
        }
        
        // find how many raters have the maximum number
        // of ratings
        for(PlainRater r : al) {
            if(r.getRatings().size() == maxNumberRatings) {
                countMaxNumRatings++;
            }
        }
        System.out.println("Max number of ratings (for rater "+raterWithMaxRatings+"): "+maxNumberRatings);
        System.out.println("Raters with max number of ratings: "+countMaxNumRatings);
        
        // find the number of ratings a particular movieID has
        for(PlainRater r : al) {
            for(Rating ra : r.getRatings()) {
                if(ra.getItem().equals(movieID)) {
                    countMovieRatings++;
                }
            }
        }
        System.out.println("MovieID "+movieID+" has number of Ratings: "+countMovieRatings);
        
        // how many different movies have been rated by all raters (totalMoviesCount)
        for(PlainRater r : al) {
            for(Rating ra : r.getRatings()) {
                if(!totalMoviesCount.contains(ra.getItem())) {
                    totalMoviesCount.add(ra.getItem());
                }
            }
        }
        System.out.println("Total movies rated by Raters: "+totalMoviesCount.size());
    }
}
