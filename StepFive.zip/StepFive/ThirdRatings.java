import java.util.*;

public class ThirdRatings {
    private ArrayList<PlainRater> myRaters;
    
    public ThirdRatings() {
        this("data/ratings.csv");
    }
    
    public ThirdRatings(String ratingsfile) {
        FirstRatings fr = new FirstRatings();
        myRaters = fr.loadRaters(ratingsfile);
    }
    
    // how much rater records were loaded
    public int getRaterSize() {
        return myRaters.size();
    }
    
    // Average movie rating for this movieID (id),
    // if there are at least minimalRaters number of ratings.
    // If there aren't at least minimalRaters number of ratings,
    // return 0
    private double getAverageByID(String id, int minimalRaters) {
        int ratingsCount = 0;
        double ratingsSum = 0;
        
        // calculate the number of raters for id (movieID)
        // and the sum of their ratings
        for(PlainRater r : myRaters) {
            for(Rating rat : r.getRatings()) {
                if(rat.getItem().equals(id)) {
                    ratingsCount++;
                    ratingsSum += rat.getValue();
                }
            }
        }
        
        // return the appropriate number
        if(ratingsCount<minimalRaters) return 0;
        else return ratingsSum/ratingsCount;
    }
    
    // returns an ArrayList<Rating> with the average ratings
    // for all movies with a number of minimalRaters
    public ArrayList<Rating> getAverageRatings(int minimalRaters) {
        ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());
        ArrayList<Rating> ra = new ArrayList<Rating>();
        
        // loop through all movieIDs, get their average ratings
        // and add them as Ratings to ra
        for(String movieID : movies) {
            if(getAverageByID(movieID, minimalRaters)>0) {
                Rating r = new Rating(movieID, getAverageByID(movieID,
                                                              minimalRaters));
                ra.add(r);
            }
        }
        
        return ra;
    }
    
    // returns an ArrayList with Ratings, satisfying a filterCriteria,
    // with minimalRaters
    public ArrayList<Rating> getAverageRatingsByFilter(int minimalRaters,
                                                       Filter filterCriteria) {
        ArrayList<String> movies = MovieDatabase.filterBy(new TrueFilter());
        ArrayList<Rating> ra = new ArrayList<Rating>();
        
        // loop through all movieIDs
        for(String movieID : movies) {
            if (filterCriteria.satisfies(movieID) &&
                getAverageByID(movieID, minimalRaters)>0) {
                ra.add(new Rating(movieID, getAverageByID(movieID,
                                                          minimalRaters)));
            }
        }
        
        return ra;
    }
}
